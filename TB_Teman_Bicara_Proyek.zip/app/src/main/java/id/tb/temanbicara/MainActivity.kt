package id.tb.temanbicara

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private const val BACKEND_URL = "http://10.0.2.2:3000/chat"
// Emulator: 10.0.2.2 points to your development computer.
// For a physical phone, replace with http://YOUR_COMPUTER_LAN_IP:3000/chat.
// For production, use an HTTPS backend URL.

data class ChatMessage(val text: String, val isUser: Boolean)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speechRecognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { TBApp(
            onSpeak = { speak(it) },
            onStopSpeaking = { tts?.stop() },
            onStartListening = { callback -> startListening(callback) },
            onStopListening = { speechRecognizer?.cancel() }
        ) }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts?.setLanguage(Locale("id", "ID"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.getDefault())
            }
            tts?.setSpeechRate(0.96f)
            tts?.setPitch(1.0f)
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tb-response")
    }

    private fun startListening(onResult: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            onResult("ERROR: Pengenalan suara tidak tersedia di perangkat ini.")
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "id-ID")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Silakan bicara dengan TB")
        }
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { onResult("ERROR: Gagal mengenali suara (kode $error). Coba lagi.") }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (spoken.isNotBlank()) onResult(spoken) else onResult("ERROR: Suara belum tertangkap. Coba lagi.")
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        speechRecognizer?.startListening(intent)
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TBApp(
    onSpeak: (String) -> Unit,
    onStopSpeaking: () -> Unit,
    onStartListening: ((String) -> Unit) -> Unit,
    onStopListening: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val messages = remember { mutableStateListOf(
        ChatMessage("Halo! Aku TB, teman bicaramu. Tekan mikrofon untuk berbicara atau ketik pesan di bawah.", false)
    ) }
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var waiting by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Siap menemani kamu") }
    var speakReplies by remember { mutableStateOf(true) }
    val client = remember { OkHttpClient() }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            listening = true
            status = "Mendengarkan…"
            onStartListening { result ->
                listening = false
                if (result.startsWith("ERROR:")) status = result.removePrefix("ERROR: ")
                else { input = result; status = "Suara berhasil dikenali" }
            }
        } else status = "Izin mikrofon diperlukan untuk berbicara"
    }

    fun sendMessage(raw: String) {
        val question = raw.trim()
        if (question.isEmpty() || waiting) return
        messages.add(ChatMessage(question, true))
        input = ""
        waiting = true
        status = "TB sedang berpikir…"
        scope.launch {
            try {
                val history = JSONArray()
                messages.dropLast(1).takeLast(16).forEach { msg ->
                    history.put(JSONObject().put("role", if (msg.isUser) "user" else "model").put("text", msg.text))
                }
                val payload = JSONObject().put("message", question).put("history", history)
                val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
                val request = Request.Builder().url(BACKEND_URL).post(body).build()
                val response = withContext(Dispatchers.IO) { client.newCall(request).execute() }
                val responseText = response.use {
                    val rawBody = it.body?.string().orEmpty()
                    if (!it.isSuccessful) throw Exception("Server ${it.code}: $rawBody")
                    JSONObject(rawBody).optString("reply", "Maaf, aku belum bisa menjawab.")
                }
                messages.add(ChatMessage(responseText, false))
                status = "Siap menemani kamu"
                if (speakReplies) onSpeak(responseText)
            } catch (e: Exception) {
                messages.add(ChatMessage("Maaf, aku tidak bisa terhubung ke server. Periksa koneksi dan alamat backend. Detail: ${e.message ?: "kesalahan jaringan"}", false))
                status = "Koneksi bermasalah"
            } finally { waiting = false }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF9B8CFF),
            secondary = Color(0xFF64D8CB),
            background = Color(0xFF10111A),
            surface = Color(0xFF1B1D2A),
            onBackground = Color(0xFFF4F3FA),
            onSurface = Color(0xFFF4F3FA)
        )
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("TB", fontWeight = FontWeight.Bold, fontSize = 22.sp)
                            Text("Teman Bicara • AI suara", fontSize = 12.sp, color = Color.LightGray)
                        }
                    },
                    actions = {
                        IconButton(onClick = { onStopSpeaking(); onStopListening(); listening = false; status = "Suara dihentikan" }) {
                            Icon(Icons.Default.Stop, contentDescription = "Hentikan suara")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF171824))
                )
            },
            bottomBar = {
                Column(Modifier.background(Color(0xFF171824)).navigationBarsPadding().padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = input,
                            onValueChange = { input = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Tulis pesan ke TB…") },
                            maxLines = 4,
                            shape = RoundedCornerShape(24.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        FilledIconButton(
                            onClick = { sendMessage(input) },
                            enabled = input.isNotBlank() && !waiting,
                            modifier = Modifier.size(52.dp)
                        ) { Icon(Icons.Default.Send, contentDescription = "Kirim pesan") }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        FilledTonalButton(
                            onClick = {
                                if (listening) {
                                    onStopListening()
                                    listening = false
                                    status = "Mendengarkan dihentikan"
                                } else {
                                    val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                                    if (granted) {
                                        listening = true
                                        status = "Mendengarkan…"
                                        onStartListening { result ->
                                            listening = false
                                            if (result.startsWith("ERROR:")) status = result.removePrefix("ERROR: ")
                                            else sendMessage(result)
                                        }
                                    } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            },
                            enabled = !waiting,
                            colors = ButtonDefaults.filledTonalButtonColors(containerColor = if (listening) Color(0xFF8A3148) else Color(0xFF34334D))
                        ) {
                            Icon(if (listening) Icons.Default.Stop else Icons.Default.Mic, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(if (listening) "Berhenti" else "Bicara")
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Jawab dengan suara", fontSize = 12.sp)
                            Switch(checked = speakReplies, onCheckedChange = { speakReplies = it })
                        }
                    }
                    Text(status, color = Color.LightGray, fontSize = 11.sp, modifier = Modifier.padding(start = 4.dp, top = 3.dp))
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp),
                contentPadding = PaddingValues(vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.size(86.dp).background(
                                    brush = androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF8D7CFF), Color(0xFF40CFC0))),
                                    shape = CircleShape
                                ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("TB", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("Teman Bicara", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                            Text(status, fontSize = 12.sp, color = Color.LightGray)
                        }
                    }
                }
                items(messages) { message ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start,
                        verticalAlignment = Alignment.Top
                    ) {
                        Surface(
                            color = if (message.isUser) Color(0xFF514A83) else Color(0xFF202231),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.widthIn(max = 320.dp)
                        ) {
                            Column(Modifier.padding(13.dp)) {
                                Text(if (message.isUser) "Kamu" else "TB", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFFB9B1FF))
                                Spacer(Modifier.height(4.dp))
                                Text(message.text, fontSize = 15.sp, lineHeight = 21.sp)
                                if (!message.isUser) {
                                    TextButton(onClick = { onSpeak(message.text) }, contentPadding = PaddingValues(0.dp)) {
                                        Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Dengarkan lagi", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
                if (waiting) item {
                    Text("TB sedang menyusun jawaban…", color = Color.LightGray, modifier = Modifier.padding(8.dp))
                }
            }
        }
    }
}
