# TB (Teman Bicara) — Android AI voice chat

Aplikasi Android native sederhana untuk ngobrol dengan AI lewat teks dan suara:
- Input suara Indonesia memakai Android `SpeechRecognizer` (ketersediaan/hasil bergantung layanan pengenalan suara di perangkat).
- Jawaban AI memakai Gemini API melalui backend Node.js.
- Jawaban dibacakan memakai Android TextToSpeech.
- Riwayat percakapan singkat dikirim agar AI dapat memahami konteks.
- API key disimpan di backend dalam file `.env`, tidak ditanam dalam APK.

> Versi ini menggunakan alur push-to-talk (tekan Bicara, ucapkan kalimat, lalu AI menjawab). Ini bukan audio streaming full-duplex seperti panggilan telepon. TTS Android dapat memakai suara yang terpasang di perangkat; kualitas dan suara offline bergantung pada mesin TTS yang tersedia.

## Struktur

```text
TB_Teman_Bicara/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── java/id/tb/temanbicara/MainActivity.kt
└── backend/
    ├── server.js
    ├── package.json
    ├── .env.example
    └── .gitignore
```

## 1. Siapkan API AI

1. Buat API key melalui Google AI Studio: https://aistudio.google.com/apikey
2. Periksa ketentuan, ketersediaan model, kuota, dan tarif terbaru untuk akun/region Anda. Ketersediaan gratis dapat berubah.
3. Jangan kirim API key ke orang lain atau memasukkannya ke kode Android.

## 2. Jalankan backend

Butuh Node.js 20 atau lebih baru.

```bash
cd backend
npm install
cp .env.example .env
```

Edit `backend/.env` dan isi `GEMINI_API_KEY` dengan key milik Anda. Jangan commit file `.env`.

Lalu jalankan:

```bash
npm start
```

Tes di komputer: buka `http://localhost:3000/health`, hasil yang diharapkan `{"ok":true,"service":"TB backend"}`.

### Menghubungkan Android ke backend

Di `MainActivity.kt`, ubah `BACKEND_URL`:
- Android Emulator di komputer yang sama: `http://10.0.2.2:3000/chat`
- HP fisik dan komputer pada Wi-Fi yang sama: `http://IP_LAN_KOMPUTER:3000/chat` (contoh IP hanya ilustrasi; cari IP lokal komputer sendiri).
- Pemakaian publik/produksi: gunakan URL backend HTTPS, jangan mengekspos port lokal ke internet.

Untuk HP fisik, firewall komputer harus mengizinkan koneksi lokal ke port 3000. Jangan gunakan HTTP tanpa TLS di jaringan publik. Konfigurasi `usesCleartextTraffic="true"` hanya untuk pengembangan lokal; hapus/nonaktifkan dan gunakan HTTPS untuk produksi.

## 3. Buka proyek Android

1. Instal Android Studio versi stabil yang mendukung Android Gradle Plugin 8.7.x.
2. Pilih **Open** lalu pilih folder `TB_Teman_Bicara`.
3. Tunggu Gradle Sync selesai. Pastikan JDK 17 tersedia.
4. Jalankan emulator Android API 26+ atau sambungkan HP dengan USB debugging.
5. Tekan **Run**.
6. Beri izin mikrofon saat diminta. Coba ketik pesan terlebih dahulu, lalu gunakan tombol **Bicara**.

## 4. Buat APK yang bisa dipasang

Di Android Studio:
- **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
- APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.
- Untuk dibagikan secara luas, gunakan **Build → Generate Signed Bundle / APK** dan buat signing key yang aman.

Lokasi file output hanya ada setelah build berhasil.

## 5. Batasan dan keamanan

- API key hanya berada di backend `.env`. Backend ini adalah template awal, bukan layanan produksi yang siap dibuka ke publik.
- Sebelum dipublikasikan, tambahkan autentikasi pengguna, HTTPS, pembatasan CORS/origin bila relevan, batas penggunaan per akun, pemantauan biaya/kuota, dan kebijakan privasi.
- Backend contoh mengirim sebagian riwayat percakapan ke penyedia AI. Jangan kirim data sensitif.
- Input suara melalui Android SpeechRecognizer dapat menggunakan layanan jaringan dari perangkat, tergantung konfigurasi Android.
- Pengguna perlu koneksi internet untuk memanggil backend dan API AI. TTS bisa offline jika paket suara tersedia.
- Model API dan kuota dapat berubah. Jika `gemini-2.5-flash` tidak tersedia, ubah `GEMINI_MODEL` pada `.env` ke model yang tersedia bagi akun Anda lalu restart server.
- Riwayat chat hanya disimpan dalam memori UI selama aplikasi berjalan; belum ada sinkronisasi atau penyimpanan permanen.

## Troubleshooting

- **Tidak terhubung**: pastikan backend aktif, URL benar, perangkat dan komputer satu jaringan jika menggunakan HP fisik, serta firewall mengizinkan koneksi.
- **API key/model error**: periksa `.env`, akses model, kuota, dan log terminal backend.
- **Mikrofon gagal**: izinkan permission mikrofon dan pastikan layanan pengenalan suara tersedia.
- **Suara tidak terdengar**: periksa volume media dan instal paket suara Bahasa Indonesia di pengaturan Text-to-Speech Android.
- **Gradle gagal**: gunakan JDK 17 dan lakukan Sync/Build ulang.

## Lisensi

Contoh kode ini disediakan sebagai titik awal pengembangan. Periksa lisensi setiap layanan/dependensi yang Anda gunakan.


## Build APK langsung dari HP (tanpa komputer)

Anda bisa mengunggah proyek ke GitHub lewat browser HP, lalu meminta GitHub Actions membangun APK di cloud. Workflow `.github/workflows/android.yml` menginstal Gradle 8.9 di runner cloud, jadi Anda tidak perlu memasang Gradle atau memiliki komputer.

Langkah dari HP:
1. Buat repositori baru di https://github.com/ lewat browser, misalnya `tb-teman-bicara`.
2. Unggah semua isi folder proyek ke repositori (termasuk `.github/workflows/android.yml` dan folder `app`, `backend`).
3. Buka tab **Actions**, pilih **Build TB Android APK**, lalu tekan **Run workflow** (atau tunggu otomatis berjalan setelah push ke branch `main`).
4. Setelah workflow berhasil, buka hasil run, unduh artifact `TB-debug-APK`, ekstrak ZIP artifact, lalu instal `app-debug.apk` di HP.

Untuk mengaktifkan jawaban AI, backend Node.js tetap perlu dijalankan di layanan hosting yang dapat menjalankan Node.js. Jangan masukkan API key ke repositori GitHub. Set `GEMINI_API_KEY` sebagai secret/environment variable di layanan backend, lalu ubah `BACKEND_URL` di `MainActivity.kt` menjadi URL HTTPS backend Anda.
